const express = require("express");
const cors = require("cors");
const OpenAI = require("openai");

const app = express();

app.use(cors());
app.use(express.json());

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

app.post("/criar-site", async (req, res) => {
  try {
    const { descricao } = req.body;

    if (!descricao) {
      return res.status(400).json({
        erro: "Descrição do site não informada."
      });
    }

    const resposta = await client.responses.create({
      model: "gpt-5.6-luna",
      input: `
Você é um especialista em criação de sites.

O usuário quer criar um site com esta descrição:

${descricao}

Crie o código completo de uma página HTML moderna, bonita,
responsiva para celular e computador.

Retorne SOMENTE o HTML completo.
Não use markdown.
Não coloque explicações antes ou depois do código.
      `
    });

    const html = resposta.output_text;

    res.json({
      html: html
    });

  } catch (erro) {
    console.error(erro);

    res.status(500).json({
      erro: "Não foi possível criar o site."
    });
  }
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Servidor funcionando na porta ${PORT}`);
});